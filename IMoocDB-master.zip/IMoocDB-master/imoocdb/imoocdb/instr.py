transaction_count = 0

